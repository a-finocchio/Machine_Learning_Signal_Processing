function fder = poly_derivative(x)
fder = 3 * x^2 - 7
end
