function f = poly(x)
f = x^3 - 7*x + 1
end
