%Read input
clear; close all; clc;
trainim = loadMNISTImages("./train-images-idx3-ubyte");
testim = loadMNISTImages("./t10k-images-idx3-ubyte");
trainlb = loadMNISTLabels("./train-labels-idx1-ubyte");
testlb = loadMNISTLabels("./t10k-labels-idx1-ubyte");

%%
X = cell(1,10);
W_final = cell(1,10);
%Get Xi
for i = 0:9
      X{i+1} = trainim(:,trainlb==i);
end


%% EM
for i = 0:9
    %Center input
    traini = X{i+1};
    traini = traini - mean(traini,2);
    
    %initialize
    k = 50;
    D = size(traini,1);
    N = size(traini,2);
    W_o = randn(D,k);
    sigma_o = abs(randn(1,1)); 
    llhvc = [];

    count = 0;
    while count <100
        if (count>2 && (llh - llhvc(end-1))/llhvc(end-1) <= 0.08)
            break;
        end
        Ezn = NaN(k,N);
        Eznn = NaN(k,k,N);
        w_1 = zeros(D,k);
        s_2 = 0;
        s_3 = 0;
        %Expectation of log-likelihood
        M = W_o'*W_o + sigma_o*eye(k,k); %k-by-k matrix
        U = chol(M);
        V = inv(U);
        iM = V*V';
        S = sum(sum(traini.^2,1)); %sample covariance
        T = inv(U')*(W_o'*traini); % T = (U')^-1 (W'*X)

        ft = D*log(2*pi);
        st = 2*sum(log(diag(U)))+(D-k)*log(sigma_o);
        tt = (S-sum(sum(abs(T).^2)))/(N*sigma_o);
        llh = -N/2*(ft+st+tt);
        llhvc = [llhvc llh];
        
        %Update/Maximization
        for n = 1:N
            Ezn(:,n) = iM*W_o'*traini(:,n);
            Eznn(:,:,n) = sigma_o*(iM)+Ezn(:,n)*Ezn(:,n)';
            w_1 = w_1 + traini(:,n)*Ezn(:,n)'; 
        end
        W_o = w_1*inv(sum(Eznn,3));

        for n =1:N
            s_2 = s_2+2*Ezn(:,n)'*W_o'*traini(:,n);
            s_3 = s_3+sum(diag(Eznn(:,:,n)*(W_o')*W_o));
        end
        sigma_o = 1/(N*D)*(S-s_2+s_3);
        
    count = count+1;
    end
    figure;
    
    for mm = 1:25
        zg = randn(k,1);
        subplot(5,5,mm);
        imshow(reshape(W_o*zg+mean(traini,2),28,28));
        title(sprintf('The %d^{th} %d,k=%d',mm,i,k));
    end
    
%     figure;
%     plot(llhvc);
%     title(sprintf("Loglikelihood check for k=%d, digit %d",k,i));
%     ylabel("LL Value");
   
end


